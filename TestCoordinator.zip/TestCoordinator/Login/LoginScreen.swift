//
//  LoginScreen.swift
//  TestCoordinator
//
//  Created by Development on 15/04/2023.
//

import SwiftUI

struct LoginScreen: View {
    var body: some View {
        Text("Login Screen")
    }
}

struct LoginScreen_Previews: PreviewProvider {
    static var previews: some View {
        LoginScreen()
    }
}
